const assetsObject = {
  carrotIcon: require('../img/carrotseeds.webp'),
  beetIcon:require('../img/download.jpg'),
  cucumberIcon: require('../img/cucumber.jpg'),
  tomattoIcon: require('../img/tomatto.jpg'),
  pumkinIcon: require('../img/pumkin.jpg'),
  broccoliIcon: require('../img/broccoli.jpg')
}
module.exports = assetsObject